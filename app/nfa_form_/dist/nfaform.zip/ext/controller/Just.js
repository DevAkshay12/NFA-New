sap.ui.define(["sap/m/MessageToast"],function(s){"use strict";return{just:function(e){s.show("Custom handler invoked.")}}});
//# sourceMappingURL=Just.js.map