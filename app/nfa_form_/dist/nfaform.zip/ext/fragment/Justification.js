sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{onPress:function(n){e.show("Custom handler invoked.")},live:function(e){debugger}}});
//# sourceMappingURL=Justification.js.map